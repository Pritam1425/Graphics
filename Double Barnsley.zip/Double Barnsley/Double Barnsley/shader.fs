#version 410
in vec4 fColor;

void main()
{
    gl_FragColor = fColor;
}
