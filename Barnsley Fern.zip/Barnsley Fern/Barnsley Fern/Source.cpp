#include <stdio.h>
#include <iostream>
#include <fstream>
#include <string.h>
#include <stdlib.h>
#include <string>
#include <GL/glew.h>
#include <GL/freeglut.h>


#include "file_utils.h"
#include "math_utils.h"
#define _CRT_SECURE_NO_WARNINGS
#pragma warning(disable:4996)
#define BUFFER_OFFSET(i) ((char *)NULL + (i))
/********************************************************************/
/*   Variables */

char theProgramTitle[] = "Barnsley Fern";
int theWindowWidth = 700, theWindowHeight = 700;
int theWindowPositionX = 40, theWindowPositionY = 40;
bool isFullScreen = false;
bool isAnimating = false;
float rotation = 0.0f;
GLuint VBO, VAO;
GLuint gWorldLocation;
GLuint posID, colorID;
typedef GLfloat point2[2];


/* Constants */
const int ANIMATION_DELAY = 20; /* milliseconds between rendering */
const char* pVSFileName = "shader.vs";
const char* pFSFileName = "shader.fs";
const char* pGSFileName = "shader.gs";

/********************************************************************
  Utility functions
 */

 /* post: compute frames per second and display in window's title bar */
void computeFPS() {
	static int frameCount = 0;
	static int lastFrameTime = 0;
	static char* title = NULL;
	int currentTime;

	if (!title)
		title = (char*)malloc((strlen(theProgramTitle) + 20) * sizeof(char));
	frameCount++;
	currentTime = glutGet((GLenum)(GLUT_ELAPSED_TIME));
	if (currentTime - lastFrameTime > 1000) {
		sprintf(title, "%s [ FPS: %4.2f ]",
			theProgramTitle,
			frameCount * 1000.0 / (currentTime - lastFrameTime));
		glutSetWindowTitle(title);
		lastFrameTime = currentTime;
		frameCount = 0;
	}
}



/********************************************************************
 Callback Functions
 These functions are registered with the glut window and called
 when certain events occur.
 */

void onInit(int argc, char* argv[])
/* pre:  glut window has been initialized
   post: model has been initialized */ {
   /* by default the back ground color is black */
	glClearColor(1.0f, 1.0f, 1.0f, 1.0f);
	//CompileShaders();
	//CreateVertexBuffer();
	glColor3f(0.133, 0.545, 0.133);
	//glColor3f(0.133, 0.545, 0.133);
	//
	//  Set up a viewing window with origin at the lower left.
	//
	glMatrixMode(GL_PROJECTION);
	glLoadIdentity();
	gluOrtho2D(-7.0, 7.0, -1.0, 10.0);
	glMatrixMode(GL_MODELVIEW);

	/* set to draw in window based on depth  */
	//glEnable(GL_DEPTH_TEST);
}

static void onDisplay() {
	//glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT);
	//glPointSize(5);

	int i;
	point2 p;
	int point_num = 100000;
	double prob[4] = { 0.85, 0.92, 0.99, 1.00 };
	double r;
	double x;
	double y;
	//
	//  Clear the window.
	//
	glClear(GL_COLOR_BUFFER_BIT);
	//
	//  Compute and plot the points.
	//
	p[0] = (double)rand()/((double)RAND_MAX);
	p[1] = (double)rand() / ((double)RAND_MAX);

	for (i = 0; i < point_num; i++)
	{
		r = (double)rand() / ((double)RAND_MAX);
		//cout << p[0] << " " << p[1] << " " << r << "\n";

		if (r < prob[0])
		{
			x = 0.85 * p[0] + 0.04 * p[1] + 0.0;
			y = -0.04 * p[0] + 0.85 * p[1] + 1.6;
		}
		else if (r < prob[1])
		{
			x = 0.20 * p[0] - 0.26 * p[1] + 0.0;
			y = 0.23 * p[0] + 0.22 * p[1] + 1.6;
		}
		else if (r < prob[2])
		{
			x = -0.15 * p[0] + 0.28 * p[1] + 0.0;
			y = 0.26 * p[0] + 0.24 * p[1] + 0.44;
		}
		else
		{
			x = 0.00 * p[0] + 0.00 * p[1] + 0.0;
			y = 0.00 * p[0] + 0.16 * p[1] + 0.0;
		}

		p[0] = x;
		p[1] = y;
		//cout << x << " " << y << "\n";
		//
		//  Plot the new point.
		//
		glBegin(GL_POINTS);
		glVertex2fv(p);
		glEnd();
	}
	//
	//  Clear all buffers.
	//
	glutSwapBuffers();

	return;
	
}

static void InitializeGlutCallbacks() {
	/* tell glut how to display model */
	glutDisplayFunc(onDisplay);
	
}

int main(int argc, char** argv) {
	glutInit(&argc, argv);

	/* request initial window size and position on the screen */
	glutInitWindowSize(theWindowWidth, theWindowHeight);
	glutInitWindowPosition(theWindowPositionX, theWindowPositionY);
	/* request full color with double buffering and depth-based rendering */
	glutInitDisplayMode(GLUT_DOUBLE | GLUT_RGBA);
	/* create window whose title is the name of the executable */
	glutCreateWindow(theProgramTitle);

	InitializeGlutCallbacks();

	// Must be done after glut is initialized!
	GLenum res = glewInit();
	if (res != GLEW_OK) {
		fprintf(stderr, "Error: '%s'\n", glewGetErrorString(res));
		return 1;
	}

	printf("GL version: %s\n", glGetString(GL_VERSION));

	/* initialize model */
	onInit(argc, argv);

	/* give control over to glut to handle rendering and interaction  */
	glutMainLoop();

	/* program should never get here */

	return 0;
}

